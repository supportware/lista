// Dados dos componentes de todas as abas
const allSheetsData = {
  "Lista GERAL": [
    {
      Item: 1,
      Componente: "SSD SATA3 120 GB",
      UND: 6,
      PRECO: 200,
      Observacoes: "Atendente a demanda",
    },
    {
      Item: 2,
      Componente: "SSD SATA3 240 GB",
      UND: 6,
      PRECO: 250,
      Observacoes: "Recomendável, não obrigatório",
    },
    {
      Item: 3,
      Componente: "Placa-mãe 1155 com ≥ 4 portas USB",
      UND: 2,
      PRECO: 500,
      Observacoes: null,
    },
    {
      Item: 4,
      Componente: "Memória DDR3 4 GB",
      UND: 6,
      PRECO: 120,
      Observacoes: "Recomendável, não obrigatório",
    },
    {
      Item: 5,
      Componente: "Resma de papel A4",
      UND: 6,
      PRECO: 30,
      Observacoes: null,
    },
    {
      Item: 6,
      Componente: "Fonte de alimentação ATX ≥ 200W",
      UND: 1,
      PRECO: 120,
      Observacoes: null,
    },
    {
      Item: 7,
      Componente: "Fechadura completa para Start do totem",
      UND: 2,
      PRECO: 0,
      Observacoes: null,
    },
    {
      Item: 8,
      Componente: "Nobreak ≥ 1200 VA",
      UND: 6,
      PRECO: 1200,
      Observacoes: "Recomendável, não obrigatório",
    },
    {
      Item: 9,
      Componente: "Adesivo no totem da Meta Reports",
      UND: 1,
      PRECO: 0,
      Observacoes: null,
    },
  ],
  "Config 128GB + recomendaveis": [
    {
      Item: 1,
      Componente: "SSD SATA3 120 GB",
      UND: 6,
      PRECO: 200,
      Observacoes: "Atendente a demanda",
    },
    {
      Item: 2,
      Componente: "Placa-mãe 1155 com ≥ 4 portas USB",
      UND: 2,
      PRECO: 500,
      Observacoes: null,
    },
    {
      Item: 3,
      Componente: "Memória DDR3 4 GB",
      UND: 6,
      PRECO: 120,
      Observacoes: "Recomendável, não obrigatório",
    },
    {
      Item: 4,
      Componente: "Resma de papel A4",
      UND: 6,
      PRECO: 30,
      Observacoes: null,
    },
    {
      Item: 5,
      Componente: "Fonte de alimentação ATX ≥ 200W",
      UND: 1,
      PRECO: 120,
      Observacoes: null,
    },
    {
      Item: 6,
      Componente: "Fechadura completa para Start do totem",
      UND: 2,
      PRECO: 0,
      Observacoes: null,
    },
    {
      Item: 7,
      Componente: "Nobreak ≥ 1200 VA",
      UND: 6,
      PRECO: 1200,
      Observacoes: "Recomendável, não obrigatório",
    },
    {
      Item: 8,
      Componente: "Adesivo no totem da Meta Reports",
      UND: 1,
      PRECO: 0,
      Observacoes: null,
    },
  ],
  "Config 240GB + recomendaveis": [
    {
      Item: 1,
      Componente: "SSD SATA3 240GB",
      UND: 6,
      PRECO: 250,
      Observacoes: "Atendente a demanda",
    },
    {
      Item: 2,
      Componente: "Placa-mãe 1155 com ≥ 4 portas USB",
      UND: 2,
      PRECO: 500,
      Observacoes: null,
    },
    {
      Item: 3,
      Componente: "Memória DDR3 4 GB",
      UND: 6,
      PRECO: 120,
      Observacoes: "Recomendável, não obrigatório",
    },
    {
      Item: 4,
      Componente: "Resma de papel A4",
      UND: 6,
      PRECO: 30,
      Observacoes: null,
    },
    {
      Item: 5,
      Componente: "Fonte de alimentação ATX ≥ 200W",
      UND: 1,
      PRECO: 120,
      Observacoes: null,
    },
    {
      Item: 6,
      Componente: "Fechadura completa para Start do totem",
      UND: 2,
      PRECO: 0,
      Observacoes: null,
    },
    {
      Item: 7,
      Componente: "Nobreak ≥ 1200 VA",
      UND: 6,
      PRECO: 1200,
      Observacoes: "Recomendável, não obrigatório",
    },
    {
      Item: 8,
      Componente: "Adesivo no totem da Meta Reports",
      UND: 1,
      PRECO: 0,
      Observacoes: null,
    },
  ],
  "Config minima": [
    {
      Item: 1,
      Componente: "SSD SATA3 120GB",
      UND: 6,
      PRECO: 200,
      Observacoes: null,
    },
    {
      Item: 2,
      Componente: "Placa-mãe 1155 com ≥ 4 portas USB",
      UND: 2,
      PRECO: 500,
      Observacoes: null,
    },
    {
      Item: 3,
      Componente: "Resma de papel A4",
      UND: 6,
      PRECO: 30,
      Observacoes: null,
    },
    {
      Item: 4,
      Componente: "Fonte de alimentação ATX ≥ 200W",
      UND: 1,
      PRECO: 120,
      Observacoes: null,
    },
    {
      Item: 5,
      Componente: "Fechadura completa para Start do totem",
      UND: 2,
      PRECO: 0,
      Observacoes: null,
    },
    {
      Item: 6,
      Componente: "Adesivo no totem da Meta Reports",
      UND: 1,
      PRECO: 0,
      Observacoes: null,
    },
  ],
};

// Mapeamento de abas para IDs
const tabMapping = {
  "Config minima": "config-minima",
  "Config 128GB + recomendaveis": "config-128gb",
  "Config 240GB + recomendaveis": "config-240gb",
  "Lista GERAL": "lista-geral",
};

// Função para formatar preço em reais
function formatPrice(price) {
  if (price === 0) {
    return "Não definido";
  }
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(price);
}

// Função para criar um card de componente
function createComponentCard(component) {
  const card = document.createElement("div");
  card.className = "component-card";

  const observationsHTML = component.Observacoes
    ? `<div class="observations">${component.Observacoes}</div>`
    : "";

  card.innerHTML = `
        <div class="component-header">
            <div class="component-item">Item ${component.Item}</div>
        </div>
        <div class="component-name">${component.Componente}</div>
        <div class="component-details">
            <div class="detail-item">
                <div class="detail-label">Quantidade</div>
                <div class="detail-value">${component.UND} unidades</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Preço Unitário</div>
                <div class="detail-value price-value">${formatPrice(
                  component.PRECO
                )}</div>
            </div>
        </div>
        ${observationsHTML}
    `;

  return card;
}

// Função para calcular o total de uma configuração
function calculateTotal(componentsData) {
  return componentsData.reduce((total, component) => {
    if (component.Item && component.PRECO !== null && component.UND !== null) {
      return total + component.PRECO * component.UND;
    }
    return total;
  }, 0);
}

// Função para calcular total de itens
function calculateTotalItems(componentsData) {
  return componentsData.reduce((total, component) => {
    if (component.Item && component.UND !== null) {
      return total + component.UND;
    }
    return total;
  }, 0);
}

// Função para criar o card de resumo
function createSummaryCard(componentsData, configName) {
  const totalValue = calculateTotal(componentsData);
  const totalItems = calculateTotalItems(componentsData);

  const summaryCard = document.createElement("div");
  summaryCard.className = "component-card summary-card";

  summaryCard.innerHTML = `
        <div class="component-header">
            <div class="component-item">Resumo</div>
        </div>
        <div class="component-name">Resumo da ${configName}</div>
        <div class="component-details">
            <div class="detail-item">
                <div class="detail-label">Total de Itens</div>
                <div class="detail-value">${totalItems} unidades</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Valor Total</div>
                <div class="detail-value price-value">${formatPrice(
                  totalValue
                )}</div>
            </div>
        </div>
        <div class="observations">
            Esta configuração contempla todos os componentes necessários para o restabelecimento do serviço de telemedicina em Portel.
        </div>
    `;

  return summaryCard;
}

// Função para renderizar componentes de uma aba específica
function renderComponents(sheetName, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const componentsData = allSheetsData[sheetName];
  if (!componentsData) return;

  // Limpar container
  container.innerHTML = "";

  // Filtrar componentes válidos
  const validComponents = componentsData.filter(
    (component) =>
      component.Item &&
      component.Componente &&
      component.UND !== null &&
      component.PRECO !== null
  );

  // Adicionar cards dos componentes
  validComponents.forEach((component, index) => {
    const card = createComponentCard(component);
    card.style.animationDelay = `${index * 0.1}s`;
    container.appendChild(card);
  });

  // Adicionar card de resumo
  const summaryCard = createSummaryCard(validComponents, sheetName);
  summaryCard.style.animationDelay = `${validComponents.length * 0.1}s`;
  container.appendChild(summaryCard);
}

// Função para gerenciar as abas
function initializeTabs() {
  const tabButtons = document.querySelectorAll(".tab-button");
  const tabPanes = document.querySelectorAll(".tab-pane");

  tabButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const targetTab = button.getAttribute("data-tab");

      // Remover classe active de todos os botões e painéis
      tabButtons.forEach((btn) => btn.classList.remove("active"));
      tabPanes.forEach((pane) => pane.classList.remove("active"));

      // Adicionar classe active ao botão clicado e painel correspondente
      button.classList.add("active");
      document.getElementById(targetTab).classList.add("active");
    });
  });
}

// Função para inicializar navegação suave
function initializeSmoothScroll() {
  const navLinks = document.querySelectorAll(".nav-link");

  navLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const targetId = link.getAttribute("href").substring(1);
      const targetElement = document.getElementById(targetId);

      if (targetElement) {
        const headerHeight = document.querySelector(".header").offsetHeight;
        const targetPosition = targetElement.offsetTop - headerHeight;

        window.scrollTo({
          top: targetPosition,
          behavior: "smooth",
        });
      }

      // Atualizar link ativo
      navLinks.forEach((navLink) => navLink.classList.remove("active"));
      link.classList.add("active");
    });
  });
}

// Função para inicializar menu mobile
function initializeMobileMenu() {
  const hamburger = document.querySelector(".hamburger");
  const navMenu = document.querySelector(".nav-menu");

  if (hamburger && navMenu) {
    hamburger.addEventListener("click", () => {
      hamburger.classList.toggle("active");
      navMenu.classList.toggle("active");
    });
  }
}

// Função para adicionar animação de entrada ao header
function animateHeader() {
  const header = document.querySelector(".header");
  header.style.opacity = "0";
  header.style.transform = "translateY(-20px)";
  header.style.transition = "all 0.6s ease";

  setTimeout(() => {
    header.style.opacity = "1";
    header.style.transform = "translateY(0)";
  }, 100);
}

// Função para inicializar scroll spy
function initializeScrollSpy() {
  const sections = document.querySelectorAll("section[id]");
  const navLinks = document.querySelectorAll(".nav-link");

  window.addEventListener("scroll", () => {
    const scrollPosition = window.scrollY + 150;

    sections.forEach((section) => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;
      const sectionId = section.getAttribute("id");

      if (
        scrollPosition >= sectionTop &&
        scrollPosition < sectionTop + sectionHeight
      ) {
        navLinks.forEach((link) => {
          link.classList.remove("active");
          if (link.getAttribute("href") === `#${sectionId}`) {
            link.classList.add("active");
          }
        });
      }
    });
  });
}

// Inicializar a página quando o DOM estiver carregado
document.addEventListener("DOMContentLoaded", function () {
  // Renderizar componentes para todas as abas
  Object.keys(allSheetsData).forEach((sheetName) => {
    const tabId = tabMapping[sheetName];
    if (tabId) {
      renderComponents(sheetName, `${tabId}-components`);
    }
  });

  // Inicializar funcionalidades
  initializeTabs();
  initializeSmoothScroll();
  initializeMobileMenu();
  initializeScrollSpy();
  animateHeader();

  // Adicionar efeito de scroll suave
  document.documentElement.style.scrollBehavior = "smooth";
});

// Função para mostrar/ocultar header no scroll
let lastScrollTop = 0;
window.addEventListener("scroll", function () {
  const header = document.querySelector(".header");
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

  if (scrollTop > lastScrollTop && scrollTop > 100) {
    // Scrolling down
    header.style.transform = "translateY(-100%)";
  } else {
    // Scrolling up
    header.style.transform = "translateY(0)";
  }

  lastScrollTop = scrollTop;
});
